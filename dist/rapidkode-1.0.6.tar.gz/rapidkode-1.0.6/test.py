import rapidkode as rk

var = rk.numbers.gen_sparsenum_upto(100)
print(var)	

var = rk.numbers.get_sparsenum_after(3289)		
print(var)	

var = rk.numbers.checkprime(8364)	
print(var)	

var = rk.numbers.getprimes.generate(100)	
print(var)	

var = rk.numbers.getprimes.inrange(100,500)	
print(var)	

var = rk.numbers.fib.getelement(58)	
print(var)	

var = rk.numbers.fib.generate(25)	
print(var)