import rapidkode as rk

var = rk.getprimefactors.fornum(6754)
print(var)

var = rk.findgcdof(97345435,8764897)
print(var)

var = rk.findinversions.forr([1, 20, 6, 4, 5])
print(var)

var = rk.catlan_numbers.getelement(15)
print(var)

var = rk.catlan_numbers.gen(28)
print(var)